# AI Cybersecurity Attack Path Simulation

## Project Description
This project simulates AI-based cybersecurity attack path analysis using multiple search algorithms and adversarial AI techniques.

Implemented Algorithms (The simulation compares the behavior and performance these):
- BFS
- DFS
- UCS
- A*
- Hill Climbing
- Minimax
- Alpha-Beta Pruning

The project also includes:
- Interactive graph visualization
- Attack paths
- Dynamic path highlighting and visualization
- Performance comparison table

--------

# Technologies Used

- Google Colab
- NetworkX
- Matplotlib
- Pandas
- ipywidgets

--------

## Required Libraries

Install dependencies using:

pip install pandas networkx matplotlib ipywidgets jinja2

---------

## How to Run

1. Open the .ipynb notebook in:
   - Google Colab
   - VS Code Jupyter
   - Jupyter Notebook

2. Run all cells sequentially.

3. Use algorithm buttons to visualize attack paths.

---

## Files Included

This project have two versions, first is without GUI for PDF and second is with GUI implemented that is .ipynb file
- AI Project_GUIversion.ipynb
- Project PDF
- Report PDF
- OverleafReport_link.txt
- README.md
